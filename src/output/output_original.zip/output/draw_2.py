import matplotlib.pyplot as plt
import seaborn as sns
from pandas import DataFrame as df
import pandas as pd
import numpy as np

data = pd.read_csv('./output/log.csv', index_col=0)

# 月平均工作时长概率密度函数估计
plt.cla()
fig = plt.figure(figsize=(10,6))
ax=sns.kdeplot(data['PID_tunerPPO_high_torque_mode:PID'] , color='b',shade=True, label='PID')
ax=sns.kdeplot(data['PID_tunerPPO_high_torque_mode:RL'] , color='r',shade=True, label='PPO-PID')
ax.set(xlabel='performance', ylabel='frequency')
plt.title('performance in electric control - PID V.S. PPO-PID')
plt.legend()

plt.savefig('./output/high_torque_mode_performance.jpg')

plt.cla()
fig = plt.figure(figsize=(10,6))
ax=sns.kdeplot(data['PID_tunerPPO_low_torque_mode:PID'] , color='b',shade=True, label='PID')
ax=sns.kdeplot(data['PID_tunerPPO_low_torque_mode:RL'] , color='r',shade=True, label='PPO-PID')
ax.set(xlabel='performance', ylabel='frequency')
plt.title('performance in electric control - PID V.S. PPO-PID')
plt.legend()

plt.savefig('./output/low_torque_mode_performance.jpg')


pass